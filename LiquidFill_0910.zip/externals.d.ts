declare module "https://*";
